package co.edu.unbosque.EscamillaCristian_Prog2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EscamillaCristianProg2Application {

	public static void main(String[] args) {
		SpringApplication.run(EscamillaCristianProg2Application.class, args);
	}

}
